# Preserving Privacy of Cloud Data Using Approximate Differential Privacy (Gaussian Mechanism)

This is the expanded Overleaf project for the B.E. project report.

## Contents
- `main.tex` — complete LaTeX report
- `figures/` — all report figures

## Expected length
The project has been compiled and verified locally at **53 PDF pages** with the supplied LaTeX source and figures.

## How to use in Overleaf
1. Create/open an Overleaf project.
2. Choose **Upload Project** and upload this ZIP.
3. Open `main.tex` if it is not already selected.
4. Click **Recompile**.
5. The expanded report should compile to approximately **53 pages**.

## Important source-alignment note
The report uses the supplied project results: Bank Marketing Dataset (4,521 rows, 17 columns), epsilon values 0.1, 0.5, 1.0, 2.0, 5.0, the main configuration epsilon=1.0 and delta=10^-5, the supplied MAE/RMSE values, and the simulated cloud-storage workflow.

Implementation details that were not supplied (such as exact programming language, cloud provider, sensitivity/clipping values, exact Gaussian noise scale, and exact perturbed columns) are explicitly marked as unspecified rather than invented.
